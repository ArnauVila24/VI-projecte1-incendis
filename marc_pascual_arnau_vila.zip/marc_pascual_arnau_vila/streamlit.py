"""
PER FUNCIONAR S'HA DE FER $> streamlit run web.py
i s'obrirà al port que digui, segurament a localhost:8501
"""

import json
import os
import streamlit as st

st.set_page_config(
    page_title="Incendis Forestals a Catalunya (1998–2024)",
    layout="wide",
    initial_sidebar_state="collapsed",
)


def load_spec(name):
    path = os.path.join("outputs", f"{name}.json")
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def show_spec(name, border=False):
    spec = load_spec(name)
    if spec is None:
        st.warning(f"No s'ha trobat `outputs/{name}.json`.")
        return

    with st.container(border=border):
        st.vega_lite_chart(spec, width="stretch")


st.title("Incendis forestals a Catalunya (1998–2024)")

show_spec("Q1V1")
show_spec("Q_UNIFICAT")

with st.expander("About"):
    st.markdown(
        """
        **Projecte:** Anàlisi visual dels incendis forestals a Catalunya (1998–2024)  
        **Fonts de dades:** Ministeri d'Agricultura, Pesca i Alimentació (1998–2022) i Generalitat de Catalunya (2023–2024)  
        **Autors:** *[Marc Pascual Ribera i Arnau Vila Bartoló]*
        """
    )